<?php

class Report {
	public function __construct() {

	}


	
}